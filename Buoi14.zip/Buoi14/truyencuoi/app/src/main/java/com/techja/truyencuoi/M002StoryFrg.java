package com.techja.truyencuoi;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class M002StoryFrg extends Fragment {
    private Context mContext;
    private ArrayList<StoryEntity> listStory;
    private String topicName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.m002_frg_story, container, false);
        initViews(rootView);
        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    private void initViews(View v) {
        v.findViewById(R.id.iv_back).setVisibility(View.VISIBLE);
        v.findViewById(R.id.iv_back).setOnClickListener(v1 -> backToM001Screen());

        TextView tvName = v.findViewById(R.id.tv_name);

        // --- SỬA 1: Hiển thị tên chủ đề đẹp hơn ---
        if (topicName.equals("gia_dinh")) {
            tvName.setText("Gia đình");
        } else {
            tvName.setText(topicName);
        }

        RecyclerView rv = v.findViewById(R.id.rv_story);
        listStory = readStory();
        StoryAdapter adapter = new StoryAdapter(listStory, mContext);
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(mContext));
    }

    private ArrayList<StoryEntity> readStory() {
        ArrayList<StoryEntity> listStory = new ArrayList<>();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(
                    new InputStreamReader(mContext.getAssets().open("story/" + topicName + ".txt"), "UTF-8"));

            String mLine;
            // --- SỬA 2: Thuật toán đọc file mới (chống lỗi mất tên truyện) ---
            while ((mLine = reader.readLine()) != null) {
                // Nếu gặp dòng trống thì bỏ qua, đọc dòng tiếp theo
                if (mLine.trim().isEmpty()) {
                    continue;
                }

                // Dòng có chữ đầu tiên sẽ là Tiêu đề (Title)
                String title = mLine;

                // Các dòng tiếp theo là nội dung, đọc cho đến khi gặp ký tự kết thúc ','0'),
                StringBuilder contentBuilder = new StringBuilder();
                while ((mLine = reader.readLine()) != null) {
                    if (mLine.contains("','0'),")) {
                        break; // Dừng lại khi gặp ký tự kết thúc truyện
                    }
                    contentBuilder.append(mLine).append("\n");
                }

                // Tạo đối tượng truyện và thêm vào danh sách
                StoryEntity storyEntity = new StoryEntity(topicName, title, contentBuilder.toString());
                listStory.add(storyEntity);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return listStory;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    private void backToM001Screen() {
        ((MainActivity) getActivity()).backToM001Screen();
    }
}