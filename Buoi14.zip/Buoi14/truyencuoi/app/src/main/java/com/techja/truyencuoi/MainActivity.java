package com.techja.truyencuoi;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String topicName; // Lưu tên chủ đề đang chọn

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bắt đầu vào màn hình Splash
        showFrg(new M000SplashFrg());
    }

    private void showFrg(Fragment frg) {
        try {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.ln_main, frg, null)
                    .commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void gotoM001Screen() {
        showFrg(new M001TopicFrg());
    }

    public void gotoM002Screen(String topicName) {
        this.topicName = topicName; // Lưu lại để dùng khi back
        M002StoryFrg frg = new M002StoryFrg();
        frg.setTopicName(topicName);
        showFrg(frg);
    }

    public void backToM001Screen() {
        gotoM001Screen();
    }

    public void gotoM003Screen(ArrayList<StoryEntity> listStory, StoryEntity story) {
        M003DetailStoryFrg frg = new M003DetailStoryFrg();
        frg.setData(topicName, listStory, story);
        showFrg(frg);
    }

    // --- QUAN TRỌNG: XỬ LÝ NÚT BACK CỨNG TRÊN ĐIỆN THOẠI ---
    @Override
    public void onBackPressed() {
        // Tìm xem fragment nào đang hiển thị
        Fragment currentFrg = getSupportFragmentManager().findFragmentById(R.id.ln_main);

        if (currentFrg instanceof M003DetailStoryFrg) {
            // Đang đọc truyện -> Quay về danh sách
            gotoM002Screen(topicName);
        } else if (currentFrg instanceof M002StoryFrg) {
            // Đang xem danh sách -> Quay về chọn chủ đề
            gotoM001Screen();
        } else if (currentFrg instanceof M001TopicFrg) {
            // Đang ở màn hình chính -> Thoát App
            super.onBackPressed();
        } else {
            super.onBackPressed();
        }
    }
}