package com.techja.truyencuoi;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class M001TopicFrg extends Fragment implements View.OnClickListener {
    private Context mContext;
    private static final String TAG = "M001TopicFrg";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.m001_frg_topic, container, false);
        initViews(rootView);
        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    private void initViews(View v) {
        LinearLayout lnMain = v.findViewById(R.id.ln_topic);
        lnMain.removeAllViews();

        try {
            // Tạo chủ đề "Gia đình"
            View vTopic = LayoutInflater.from(mContext).inflate(R.layout.item_topic, null);

            // --- SỬA Ở ĐÂY: KHÔNG can thiệp vào ImageView nữa để nó tự lấy ảnh từ XML ---
            // ImageView ivTopic = vTopic.findViewById(R.id.iv_topic);
            // ivTopic.setImageResource(android.R.drawable.ic_menu_gallery); // <--- DÒNG NÀY GÂY LỖI MẤT ẢNH

            TextView tvTopic = vTopic.findViewById(R.id.tv_topic);
            tvTopic.setText("Gia đình");

            lnMain.addView(vTopic);

            // Chỉnh khoảng cách (Margin)
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) vTopic.getLayoutParams();
            params.bottomMargin = 40;
            vTopic.setLayoutParams(params);

            // Gắn tag để biết user chọn chủ đề nào
            vTopic.setTag("gia_dinh");
            vTopic.setOnClickListener(this);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        String topicName = (String) v.getTag();
        ((MainActivity) getActivity()).gotoM002Screen(topicName);
    }
}