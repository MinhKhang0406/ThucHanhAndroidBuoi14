package com.techja.truyencuoi;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public class M000SplashFrg extends Fragment {
    private static final String TAG = "M000SplashFrg";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView: Tạo view splash");
        View view = inflater.inflate(R.layout.m000_frg_splash, container, false);
        initViews();
        return view;
    }

    private void initViews() {
        Log.d(TAG, "initViews: Bắt đầu đếm ngược 2 giây");
        new Handler().postDelayed(() -> {
            Log.d(TAG, "initViews: Đã đợi 2 giây, chuyển màn hình");
            gotoM001Screen();
        }, 2000);
    }

    private void gotoM001Screen() {
        try {
            Log.d(TAG, "gotoM001Screen: Gọi MainActivity");
            ((MainActivity) getActivity()).gotoM001Screen();
        } catch (Exception e) {
            Log.e(TAG, "Lỗi gotoM001Screen: " + e.getMessage(), e);
        }
    }
}